package com.example.library.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.library.entities.Admin;
import com.example.library.entities.Constants;
import com.example.library.service.HelperService;
import com.example.library.entities.Message;
import com.example.library.entities.Book;

@Controller
@RequestMapping("/app/**")
public class loginController {

	@Autowired
	HelperService helperService;

	@Autowired
	private com.example.library.repo.BookRepository bookRepository;

	@Autowired
	private com.example.library.repo.StudentRepository studentRepository;

	@Autowired
	private com.example.library.repo.TransactionRepository transactionRepository;

	public loginController() {
	}

	/*
	 * Handling of Request to Open HOME PAGE
	 */
	@GetMapping("/app/home")
	public String getBookById(Model model, HttpSession session) {

		model.addAttribute("title", "Home");
		return "Basic/home";
	}

	/*
	 * Handling of Request to Open LOGIN PAGE
	 */
	@GetMapping("/app/login")
	public String login(Model model, HttpSession session) {

		System.out.println("DEBUG...1\n");

		model.addAttribute("title", "Login");
		model.addAttribute("admin", new Admin());
		return "Basic/login";
	}

	/*
	 * Handling of Request to Open REGISTER PAGE
	 */
	@GetMapping("/app/register")
	public String registerPage(Model model, HttpSession session) {
		model.addAttribute("title", "Register");
		model.addAttribute("admin", new Admin());
		return "register";
	}

	/*
	 * Handling of Request to REGISTER Admin
	 */
	@PostMapping("/app/register")
	public String registerAdmin(@ModelAttribute("admin") Admin admin, Model model, HttpSession session) {
		if (admin.getUsername() == null || admin.getUsername().trim().isEmpty() ||
			admin.getPassword() == null || admin.getPassword().trim().isEmpty()) {
			session.setAttribute("message", new Message("Username and Password are required", "alert-danger"));
			model.addAttribute("title", "Register");
			model.addAttribute("admin", admin);
			return "register";
		}
		
		Constants.REGISTERED_ADMINS.put(admin.getUsername(), admin.getPassword());
		session.setAttribute("message", new Message("Registration successful! Please login.", "alert-success"));
		return "redirect:/app/login";
	}

	/*
	 * Handling of LOGOUT Request
	 */
	@PostMapping("/app/logout")
	public String logout(Model model, HttpSession session) throws IOException, ServletException {
		session.removeAttribute(Constants.SESSION_ADMIN);

		model.addAttribute("title", "Login");
		model.addAttribute("admin", new Admin());
		return "Basic/login";
	}

	/*
	 * Handling of Request to verify Login Credentials
	 */
	@PostMapping("/app/verify")
	public String dashboard(@ModelAttribute("admin") Admin admin, Model model, HttpSession session) {

		return helperService.verifyAdmin(admin, model, session);

	}

	/*
	 * Handling of Request to Open DASHBOARD
	 */
	@GetMapping("/app/dashboard")
	public String backToDashboard(Model model, HttpSession session) {

		if (checkSession(session).equals(Constants.SESSION_NOTOK)) {
			model.addAttribute("title", "Login");
			model.addAttribute("admin", new Admin());
			return "Basic/login";
		}

		// Calculate stats
		long totalBooks = bookRepository.count();
		long issuedBooks = bookRepository.findAll().stream().filter(Book::isIssued).count();
		long availableBooks = totalBooks - issuedBooks;
		long totalStudents = studentRepository.count();

		// Fetch recent transactions (limit to 5)
		java.util.List<com.example.library.entities.Transaction> recentTransactions = transactionRepository.findByOrderBySrNrDesc();
		if (recentTransactions.size() > 5) {
			recentTransactions = recentTransactions.subList(0, 5);
		}

		model.addAttribute("totalBooks", totalBooks);
		model.addAttribute("issuedBooks", issuedBooks);
		model.addAttribute("availableBooks", availableBooks);
		model.addAttribute("totalStudents", totalStudents);
		model.addAttribute("recentTransactions", recentTransactions);

		model.addAttribute("title", "Dashboard");
		return "Basic/dashboard";
	}

	/**
	 * This method checks session
	 * 
	 * @param session
	 * @return
	 */
	private String checkSession(HttpSession session) {
		String sessionInfo = (String) session.getAttribute(Constants.SESSION_ADMIN);

		if (sessionInfo == null) {
			session.setAttribute("message", new Message("SESSION NOT VALID PLEASE LOGIN AGAIN!!!", "alert-danger"));
			return Constants.SESSION_NOTOK;
		} else {
			return Constants.SESSION_OK;
			
		}
	}

}
